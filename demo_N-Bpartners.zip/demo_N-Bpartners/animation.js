document.addEventListener('DOMContentLoaded', function() {
    // ボタン要素を取得
    const btn = document.getElementById('shakeBtn');

    // ホバー時のイベントリスナーを追加
    btn.addEventListener('mouseenter', function() {
        // ボタンがホバーされたら揺れるアニメーションを適用
        btn.classList.add('shake-animation');
    });

    // ホバーから外れた時のイベントリスナーを追加
    btn.addEventListener('mouseleave', function() {
        // ボタンから外れたら揺れるアニメーションを削除
        btn.classList.remove('shake-animation');
    });
});
